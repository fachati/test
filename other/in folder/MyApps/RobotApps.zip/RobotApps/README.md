Android-Service-Example
=======================

In this tutorial we will learn how to create a service, and service lifecycle methods. 

