package com.javatechig.robot;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.os.IBinder;
import android.provider.Browser;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class HelloService extends Service {

    private static final String TAG = "Service";


    @Override
    public void onCreate() {
        Log.i(TAG, "Service onCreate");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i(TAG, "Service onStartCommand");


        Timer timerAsync = new Timer();
        TimerTask timerTaskAsync = new TimerTask() {
            @Override
            public void run() {
                System.out.println("***************************** im here**");
                clearCacheChrome();
                RestartApps();
            }
        };
        timerAsync.schedule(timerTaskAsync, 0, 300000);// 5 min
        return Service.START_STICKY;
    }


    @Override
    public IBinder onBind(Intent arg0) {
        Log.i(TAG, "Service onBind");
        return null;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "Service onDestroy");
    }

    public void RestartApps(){
        try {

            Process suProcess = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(suProcess.getOutputStream());

            os.writeBytes("adb shell" + "\n");
            os.flush();

            os.writeBytes("am force-stop com.fachati.TestAdds\n");
            os.flush();
            os.writeBytes("pm clear com.fachati.TestAdds\n");
            os.flush();

            os.writeBytes("am force-stop com.android.chrome\n");
            os.flush();
            os.writeBytes("pm clear com.android.chrome\n");
            os.flush();

            os.writeBytes("am force-stop com.android.vending\n");
            os.flush();
            os.writeBytes("pm clear com.android.vending\n");
            os.flush();

            /*os.writeBytes("pm clear com.google.android.gms\n");
            os.flush();*/

            os.close();
            suProcess.waitFor();


            Thread.sleep(2000);
            Intent i = this.getPackageManager().getLaunchIntentForPackage("com.fachati.TestAdds");
            this.startActivity(i);

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public void clearCacheChrome(){
        ContentResolver cR = getContentResolver();

        if(Browser.canClearHistory(cR)){
            Browser.clearHistory(cR);
            Browser.clearSearches(cR);
        }
    }
}