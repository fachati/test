package com.javatechig.robot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.javatechig.serviceexample.R;


public class HelloActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello);


        Intent intent = new Intent(HelloActivity.this, HelloService.class);
        startService(intent);

    }
}
